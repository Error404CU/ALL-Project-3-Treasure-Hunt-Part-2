class Robot():
    def __init__(self, x, y, size, score=0):
        self.x = x
        self.y = y
        self.size = size
        self.score = score
    def drawRobot(self, canvas):
        self.canvas = canvas
        self.shape = canvas.create_rectangle(self.x, self.y, self.x + self.size, self.y + self.size)
    def moveRobot(self, a, b):
        self.a = a
        self.b = b
        self.x += self.a
        self.y += self.b
        self.canvas.coords(self.shape, self.x, self.y, self.x + self.size, self.y + self.size)
        time.sleep(0.025)
        self.canvas.update()
    def scoreRobot(self, canvas):
        self.canvas = canvas
        self.q = canvas.create_text(840, 15, text="Score: %r" % self.score)
        self.canvas.delete(self.q)
        self.q = canvas.create_text(840, 15, text="Score: %r" % self.score)
