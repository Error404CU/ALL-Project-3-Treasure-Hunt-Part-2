from Tkinter import *
from Template import *
from Classes import *


r = Robot(10, 10, 10)
r.drawRobot(canvas)
r.scoreRobot(canvas)


root.mainloop()